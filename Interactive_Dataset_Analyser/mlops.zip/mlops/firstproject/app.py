import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from scipy import stats
import io

# Set page config
st.set_page_config(page_title="Advanced Data Analysis Dashboard", layout="wide")

# Apply custom styling
st.markdown("""
    <style>
    .main {
        padding: 2rem;
    }
    .stAlert {
        margin-top: 1rem;
    }
    </style>
    """, unsafe_allow_html=True)

# Title of the app with description
st.title("Advanced Data Analysis Dashboard")
st.markdown("""
    This dashboard provides comprehensive data analysis tools including:
    - Basic statistics and data preview
    - Advanced visualizations
    - Data transformation tools
    - Statistical tests
    - Outlier detection
    """)

# File uploader with additional options
uploaded_file = st.file_uploader("Upload your CSV data file", type=["csv"])
if uploaded_file is not None:
    # Add file options
    file_options = st.expander("File Import Options")
    with file_options:
        separator = st.text_input("CSV Separator", ",")
        encoding = st.selectbox("File Encoding", ["utf-8", "iso-8859-1", "cp1252"])

        try:
            data = pd.read_csv(uploaded_file, sep=separator, encoding=encoding)
            st.success("File successfully loaded!")
        except Exception as e:
            st.error(f"Error reading file: {str(e)}")
            st.stop()

    # Create tabs for different analysis sections
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "Data Overview",
        "Data Transformation",
        "Visualizations",
        "Statistical Analysis",
        "Outlier Detection"
    ])

    with tab1:
        st.subheader("Data Preview")
        col1, col2 = st.columns(2)
        with col1:
            st.write("First few rows:")
            st.dataframe(data.head())
        with col2:
            st.write("Data Info:")
            buffer = io.StringIO()
            data.info(buf=buffer)
            st.text(buffer.getvalue())

        st.subheader("Summary Statistics")
        st.dataframe(data.describe())

        # Missing values analysis
        st.subheader("Missing Values Analysis")
        missing_data = data.isnull().sum()
        if missing_data.any():
            missing_df = pd.DataFrame({
                'Column': missing_data.index,
                'Missing Values': missing_data.values,
                'Percentage': (missing_data.values / len(data) * 100).round(2)
            })
            st.dataframe(missing_df[missing_df['Missing Values'] > 0])
        else:
            st.info("No missing values found in the dataset!")

    with tab2:
        st.subheader("Data Transformation Tools")

        # Separate numerical and categorical columns
        numerical_columns = data.select_dtypes(include=['float64', 'int64']).columns
        categorical_columns = data.select_dtypes(include=['object']).columns

        # Column transformation
        transform_type = st.selectbox(
            "Select Transformation Type",
            ["Text to Numerical", "Numerical Scaling", "Handle Missing Values"]
        )

        if transform_type == "Text to Numerical":
            if not categorical_columns.empty:
                text_column = st.selectbox("Select Text Column:", categorical_columns)
                encoding_type = st.selectbox(
                    "Choose Encoding Type:",
                    ["One-Hot Encoding", "Binary Encoding", "Label Encoding"]
                )

                if st.button("Transform"):
                    if encoding_type == "One-Hot Encoding":
                        encoded_df = pd.get_dummies(data[text_column], prefix=text_column)
                        data = pd.concat([data, encoded_df], axis=1)
                    elif encoding_type == "Binary Encoding":
                        unique_values = data[text_column].unique()
                        binary_map = {value: idx for idx, value in enumerate(unique_values)}
                        data[text_column + '_binary'] = data[text_column].map(binary_map)
                    else:  # Label Encoding
                        data[text_column + '_label'] = pd.Categorical(data[text_column]).codes

                    st.success(f"Transformed {text_column} using {encoding_type}")
                    st.dataframe(data.head())

        elif transform_type == "Numerical Scaling":
            if not numerical_columns.empty:
                num_column = st.selectbox("Select Numerical Column:", numerical_columns)
                scaling_type = st.selectbox(
                    "Choose Scaling Type:",
                    ["Min-Max Scaling", "Standard Scaling", "Log Transform"]
                )

                if st.button("Scale"):
                    if scaling_type == "Min-Max Scaling":
                        data[num_column + '_scaled'] = (data[num_column] - data[num_column].min()) / \
                                                       (data[num_column].max() - data[num_column].min())
                    elif scaling_type == "Standard Scaling":
                        data[num_column + '_scaled'] = (data[num_column] - data[num_column].mean()) / \
                                                       data[num_column].std()
                    else:  # Log Transform
                        if (data[num_column] > 0).all():
                            data[num_column + '_log'] = np.log(data[num_column])
                        else:
                            st.warning("Log transform not possible due to non-positive values")

                    st.success(f"Scaled {num_column} using {scaling_type}")
                    st.dataframe(data.head())

        elif transform_type == "Handle Missing Values":
            missing_cols = data.columns[data.isnull().any()].tolist()
            if missing_cols:
                col = st.selectbox("Select Column with Missing Values:", missing_cols)
                method = st.selectbox(
                    "Choose Handling Method:",
                    ["Mean", "Median", "Mode", "Forward Fill", "Backward Fill", "Drop Rows"]
                )

                if st.button("Handle Missing Values"):
                    if method in ["Mean", "Median", "Mode"]:
                        if method == "Mean":
                            data[col].fillna(data[col].mean(), inplace=True)
                        elif method == "Median":
                            data[col].fillna(data[col].median(), inplace=True)
                        else:
                            data[col].fillna(data[col].mode()[0], inplace=True)
                    elif method == "Forward Fill":
                        data[col].fillna(method='ffill', inplace=True)
                    elif method == "Backward Fill":
                        data[col].fillna(method='bfill', inplace=True)
                    else:
                        data.dropna(subset=[col], inplace=True)

                    st.success(f"Handled missing values in {col} using {method}")
                    st.dataframe(data.head())
            else:
                st.info("No missing values found in the dataset!")

    with tab3:
        st.subheader("Advanced Visualizations")

        viz_type = st.selectbox(
            "Choose Visualization Type",
            ["Basic Plots", "Advanced Plots", "Custom Plots"]
        )

        if viz_type == "Basic Plots":
            plot_type = st.selectbox(
                "Select Plot Type",
                ["Scatter Plot", "Line Plot", "Bar Plot", "Histogram", "Box Plot"]
            )

            if plot_type in ["Scatter Plot", "Line Plot", "Bar Plot"]:
                col1, col2 = st.columns(2)
                with col1:
                    x_var = st.selectbox("Select X-axis variable:", numerical_columns)
                with col2:
                    y_var = st.selectbox("Select Y-axis variable:", numerical_columns)

                color_var = st.selectbox("Select Color variable (optional):",
                                         ["None"] + list(categorical_columns))

            elif plot_type == "Histogram":
                x_var = st.selectbox("Select variable:", numerical_columns)
                bins = st.slider("Number of bins:", 5, 100, 30)

            elif plot_type == "Box Plot":
                y_var = st.selectbox("Select variable:", numerical_columns)
                x_var = st.selectbox("Select grouping variable:",
                                     ["None"] + list(categorical_columns))

            if st.button("Generate Plot"):
                fig, ax = plt.subplots(figsize=(10, 6))

                if plot_type == "Scatter Plot":
                    if color_var != "None":
                        sns.scatterplot(data=data, x=x_var, y=y_var, hue=color_var)
                    else:
                        sns.scatterplot(data=data, x=x_var, y=y_var)
                    plt.title(f'Scatter Plot: {x_var} vs {y_var}')

                elif plot_type == "Line Plot":
                    if color_var != "None":
                        sns.lineplot(data=data, x=x_var, y=y_var, hue=color_var)
                    else:
                        sns.lineplot(data=data, x=x_var, y=y_var)
                    plt.title(f'Line Plot: {x_var} vs {y_var}')

                elif plot_type == "Bar Plot":
                    if color_var != "None":
                        sns.barplot(data=data, x=x_var, y=y_var, hue=color_var)
                    else:
                        sns.barplot(data=data, x=x_var, y=y_var)
                    plt.title(f'Bar Plot: {x_var} vs {y_var}')

                elif plot_type == "Histogram":
                    sns.histplot(data=data, x=x_var, bins=bins, kde=True)
                    plt.title(f'Histogram of {x_var}')

                elif plot_type == "Box Plot":
                    if x_var != "None":
                        sns.boxplot(data=data, x=x_var, y=y_var)
                    else:
                        sns.boxplot(data=data, y=y_var)
                    plt.title(f'Box Plot of {y_var}')

                st.pyplot(fig)

        elif viz_type == "Advanced Plots":
            advanced_plot = st.selectbox(
                "Select Advanced Plot Type",
                ["Correlation Heatmap", "Pair Plot", "Joint Plot", "Violin Plot"]
            )

            if advanced_plot == "Correlation Heatmap":
                if st.button("Generate Heatmap"):
                    corr_matrix = data.select_dtypes(include=['float64', 'int64']).corr()
                    fig, ax = plt.subplots(figsize=(10, 8))
                    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0)
                    plt.title("Correlation Heatmap")
                    st.pyplot(fig)

            elif advanced_plot == "Pair Plot":
                selected_cols = st.multiselect(
                    "Select columns for pair plot (2-5 recommended):",
                    numerical_columns,
                    default=list(numerical_columns)[:3]
                )
                hue_var = st.selectbox(
                    "Select categorical variable for color coding (optional):",
                    ["None"] + list(categorical_columns)
                )

                if st.button("Generate Pair Plot"):
                    if hue_var != "None":
                        g = sns.pairplot(data[selected_cols + [hue_var]], hue=hue_var)
                    else:
                        g = sns.pairplot(data[selected_cols])
                    st.pyplot(g.fig)

            elif advanced_plot == "Joint Plot":
                col1, col2 = st.columns(2)
                with col1:
                    x_var = st.selectbox("Select X-axis variable:", numerical_columns)
                with col2:
                    y_var = st.selectbox("Select Y-axis variable:", numerical_columns)

                kind = st.selectbox("Select kind:", ["scatter", "kde", "hex", "reg"])

                if st.button("Generate Joint Plot"):
                    g = sns.jointplot(data=data, x=x_var, y=y_var, kind=kind)
                    st.pyplot(g.fig)

            elif advanced_plot == "Violin Plot":
                y_var = st.selectbox("Select numerical variable:", numerical_columns)
                x_var = st.selectbox("Select categorical variable:", categorical_columns)

                if st.button("Generate Violin Plot"):
                    fig, ax = plt.subplots(figsize=(10, 6))
                    sns.violinplot(data=data, x=x_var, y=y_var)
                    plt.xticks(rotation=45)
                    st.pyplot(fig)

    with tab4:
        st.subheader("Statistical Analysis")

        test_type = st.selectbox(
            "Choose Statistical Test",
            ["Descriptive Statistics", "Correlation Analysis", "Hypothesis Testing"]
        )

        if test_type == "Descriptive Statistics":
            selected_col = st.selectbox("Select Column:", numerical_columns)

            col1, col2 = st.columns(2)
            with col1:
                st.write("Basic Statistics:")
                stats_df = pd.DataFrame({
                    'Statistic': ['Mean', 'Median', 'Std Dev', 'Skewness', 'Kurtosis'],
                    'Value': [
                        data[selected_col].mean(),
                        data[selected_col].median(),
                        data[selected_col].std(),
                        data[selected_col].skew(),
                        data[selected_col].kurtosis()
                    ]
                })
                st.dataframe(stats_df)

            with col2:
                st.write("Quantiles:")
                quantiles = data[selected_col].quantile([0.1, 0.25, 0.5, 0.75, 0.9])
                st.dataframe(pd.DataFrame(quantiles, columns=['Value']))

        elif test_type == "Correlation Analysis":
            col1, col2 = st.columns(2)
            with col1:
                var1 = st.selectbox("Select first variable:", numerical_columns)
            with col2:
                var2 = st.selectbox("Select second variable:", numerical_columns)

            if st.button("Calculate Correlation"):
                pearson_corr, p_value = stats.pearsonr(data[var1], data[var2])
                spearman_corr, spearman_p = stats.spearmanr(data[var1], data[var2])

                st.write("Correlation Results:")
                corr_df = pd.DataFrame({
                    'Metric': ['Pearson Correlation', 'Pearson P-value',
                               'Spearman Correlation', 'Spearman P-value'],
                    'Value': [
                        round(pearson_corr, 4),
                        round(p_value, 4),
                        round(spearman_corr, 4),
                        round(spearman_p, 4)
                    ]
                })
                st.dataframe(corr_df)

                # Visualization of correlation
                fig, ax = plt.subplots(figsize=(8, 6))
                sns.regplot(data=data, x=var1, y=var2)
                plt.title(f'Correlation between {var1} and {var2}')
                st.pyplot(fig)

            elif test_type == "Hypothesis Testing":
                test_selection = st.selectbox(
                    "Select Test Type",
                    ["One Sample T-Test", "Two Sample T-Test", "Chi-Square Test"]
                )

                if test_selection == "One Sample T-Test":
                    col1, col2 = st.columns(2)
                    with col1:
                        test_var = st.selectbox("Select variable to test:", numerical_columns)
                    with col2:
                        pop_mean = st.number_input("Population mean to test against:", value=0.0)

                    if st.button("Run T-Test"):
                        t_stat, p_value = stats.ttest_1samp(data[test_var], pop_mean)
                        st.write("One Sample T-Test Results:")
                        results_df = pd.DataFrame({
                            'Metric': ['T-Statistic', 'P-Value'],
                            'Value': [round(t_stat, 4), round(p_value, 4)]
                        })
                        st.dataframe(results_df)

                        # Interpretation
                        alpha = 0.05
                        st.write("### Interpretation")
                        if p_value < alpha:
                            st.write(
                                f"At α = {alpha}, we reject the null hypothesis that the population mean equals {pop_mean}.")
                        else:
                            st.write(
                                f"At α = {alpha}, we fail to reject the null hypothesis that the population mean equals {pop_mean}.")

                elif test_selection == "Two Sample T-Test":
                    col1, col2 = st.columns(2)
                    with col1:
                        group_var = st.selectbox("Select grouping variable:", categorical_columns)
                    with col2:
                        test_var = st.selectbox("Select test variable:", numerical_columns)

                    if st.button("Run Two Sample T-Test"):
                        unique_groups = data[group_var].unique()
                        if len(unique_groups) < 2:
                            st.error("Need at least two groups for comparison")
                        else:
                            group1 = data[data[group_var] == unique_groups[0]][test_var]
                            group2 = data[data[group_var] == unique_groups[1]][test_var]
                            t_stat, p_value = stats.ttest_ind(group1, group2)

                            st.write("Two Sample T-Test Results:")
                            results_df = pd.DataFrame({
                                'Metric': ['T-Statistic', 'P-Value'],
                                'Value': [round(t_stat, 4), round(p_value, 4)]
                            })
                            st.dataframe(results_df)

                            # Visualization
                            fig, ax = plt.subplots(figsize=(10, 6))
                            sns.boxplot(data=data, x=group_var, y=test_var)
                            plt.title(f'Distribution of {test_var} by {group_var}')
                            st.pyplot(fig)

                elif test_selection == "Chi-Square Test":
                    col1, col2 = st.columns(2)
                    with col1:
                        var1 = st.selectbox("Select first categorical variable:", categorical_columns)
                    with col2:
                        var2 = st.selectbox("Select second categorical variable:", categorical_columns)

                    if st.button("Run Chi-Square Test"):
                        contingency_table = pd.crosstab(data[var1], data[var2])
                        chi2, p_value, dof, expected = stats.chi2_contingency(contingency_table)

                        st.write("Chi-Square Test Results:")
                        results_df = pd.DataFrame({
                            'Metric': ['Chi-Square Statistic', 'P-Value', 'Degrees of Freedom'],
                            'Value': [round(chi2, 4), round(p_value, 4), dof]
                        })
                        st.dataframe(results_df)

                        # Display contingency table
                        st.write("Contingency Table:")
                        st.dataframe(contingency_table)

            with tab5:
                st.subheader("Outlier Detection")

                outlier_method = st.selectbox(
                    "Select Outlier Detection Method",
                    ["Z-Score", "IQR Method", "Isolation Forest"]
                )

                if outlier_method in ["Z-Score", "IQR Method"]:
                    selected_col = st.selectbox("Select Column for Outlier Detection:", numerical_columns)

                    if outlier_method == "Z-Score":
                        z_threshold = st.slider("Z-Score Threshold", 1.0, 4.0, 3.0, 0.1)

                        if st.button("Detect Outliers"):
                            z_scores = np.abs(stats.zscore(data[selected_col]))
                            outliers = data[z_scores > z_threshold]

                            st.write(f"Found {len(outliers)} outliers using Z-Score method:")
                            if not outliers.empty:
                                st.dataframe(outliers)

                                # Visualization
                                fig, ax = plt.subplots(figsize=(10, 6))
                                sns.boxplot(y=data[selected_col])
                                plt.title(f'Box Plot of {selected_col} showing outliers')
                                st.pyplot(fig)

                    elif outlier_method == "IQR Method":
                        iqr_multiplier = st.slider("IQR Multiplier", 1.0, 3.0, 1.5, 0.1)

                        if st.button("Detect Outliers"):
                            Q1 = data[selected_col].quantile(0.25)
                            Q3 = data[selected_col].quantile(0.75)
                            IQR = Q3 - Q1
                            outliers = data[(data[selected_col] < (Q1 - iqr_multiplier * IQR)) |
                                            (data[selected_col] > (Q3 + iqr_multiplier * IQR))]

                            st.write(f"Found {len(outliers)} outliers using IQR method:")
                            if not outliers.empty:
                                st.dataframe(outliers)

                                # Visualization
                                fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
                                # Box plot
                                sns.boxplot(y=data[selected_col], ax=ax1)
                                ax1.set_title('Box Plot')
                                # Distribution plot
                                sns.histplot(data=data, x=selected_col, ax=ax2)
                                ax2.axvline(Q1 - iqr_multiplier * IQR, color='r', linestyle='--')
                                ax2.axvline(Q3 + iqr_multiplier * IQR, color='r', linestyle='--')
                                ax2.set_title('Distribution with Outlier Thresholds')
                                plt.tight_layout()
                                st.pyplot(fig)

                elif outlier_method == "Isolation Forest":
                    selected_cols = st.multiselect(
                        "Select Columns for Outlier Detection:",
                        numerical_columns,
                        default=list(numerical_columns)[:2]
                    )

                    contamination = st.slider("Contamination Factor", 0.01, 0.5, 0.1, 0.01)

                    if st.button("Detect Outliers"):
                        from sklearn.ensemble import IsolationForest

                        iso_forest = IsolationForest(contamination=contamination, random_state=42)
                        outliers = iso_forest.fit_predict(data[selected_cols])
                        outlier_df = data[outliers == -1]

                        st.write(f"Found {len(outlier_df)} outliers using Isolation Forest:")
                        if not outlier_df.empty:
                            st.dataframe(outlier_df)

                            # Visualization if 2 columns selected
                            if len(selected_cols) == 2:
                                fig, ax = plt.subplots(figsize=(10, 6))
                                plt.scatter(data[selected_cols[0]], data[selected_cols[1]],
                                            c=outliers, cmap='viridis')
                                plt.xlabel(selected_cols[0])
                                plt.ylabel(selected_cols[1])
                                plt.title('Isolation Forest Outlier Detection')
                                plt.colorbar(label='Outlier')
                                st.pyplot(fig)

                else:
                    st.warning("Please upload a CSV file to proceed.")